import java.util.Scanner;

class BankTransaction extends Thread {
    private int amount;
    private boolean highValue;

    BankTransaction(String name, int amount, boolean highValue) {
        super(name);
        this.amount = amount;
        this.highValue = highValue;
    }

    public void run() {
        if (highValue) {
            System.out.println("High-value transaction processed first (" + getName()
                    + ": \u20B9" + amount + ", priority " + getPriority() + ")");
        } else {
            System.out.println("Low-value transaction processed later (" + getName()
                    + ": \u20B9" + amount + ", priority " + getPriority() + ")");
        }
    }
}

public class Q10_BankTransaction {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Transaction1: \u20B9");
        int a1 = sc.nextInt();
        System.out.print("Transaction2: \u20B9");
        int a2 = sc.nextInt();

        final int LIMIT = 10000;   // amounts >= 10000 are "high value"
        BankTransaction t1 = new BankTransaction("Transaction1", a1, a1 >= LIMIT);
        BankTransaction t2 = new BankTransaction("Transaction2", a2, a2 >= LIMIT);

        t1.setPriority(a1 >= LIMIT ? Thread.MAX_PRIORITY : Thread.MIN_PRIORITY);
        t2.setPriority(a2 >= LIMIT ? Thread.MAX_PRIORITY : Thread.MIN_PRIORITY);

        // Start the higher-priority thread first so the order is predictable
        BankTransaction first = t1.getPriority() >= t2.getPriority() ? t1 : t2;
        BankTransaction second = (first == t1) ? t2 : t1;
        first.start();
        first.join();
        second.start();
        second.join();
        sc.close();
    }
}
