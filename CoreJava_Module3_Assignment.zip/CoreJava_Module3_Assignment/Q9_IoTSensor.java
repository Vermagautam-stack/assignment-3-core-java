import java.util.Random;
import java.util.Scanner;

class SquareCalculator extends Thread {
    private int number;

    SquareCalculator(int number) {
        this.number = number;
    }

    public void run() {
        System.out.println("Square: " + (number * number));
    }
}

class CubeCalculator extends Thread {
    private int number;

    CubeCalculator(int number) {
        this.number = number;
    }

    public void run() {
        System.out.println("Cube: " + (number * number * number));
    }
}

class RandomNumberGenerator extends Thread {
    private int count;

    RandomNumberGenerator(int count) {
        this.count = count;
    }

    public void run() {
        Random rand = new Random();
        try {
            for (int i = 0; i < count; i++) {
                int n = rand.nextInt(20) + 1;   // random number 1..20
                System.out.println("Generated: " + n);

                Thread worker;
                if (n % 2 == 0) {
                    worker = new SquareCalculator(n);   // even -> square
                } else {
                    worker = new CubeCalculator(n);     // odd -> cube
                }
                worker.start();
                worker.join();
                Thread.sleep(1000);   // sensor generates every second
            }
        } catch (InterruptedException e) {
            System.out.println("Simulation interrupted");
        }
    }
}

public class Q9_IoTSensor {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nMenu:\n1. Start Simulation\n2. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            if (choice == 1) {
                RandomNumberGenerator gen = new RandomNumberGenerator(5);
                gen.start();
                gen.join();
            } else if (choice == 2) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid choice");
            }
        }
        sc.close();
    }
}
