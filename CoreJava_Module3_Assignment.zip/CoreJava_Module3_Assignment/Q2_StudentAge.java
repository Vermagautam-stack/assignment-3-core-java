import java.util.Scanner;

class InvalidAgeException extends Exception {
    InvalidAgeException(String message) {
        super(message);
    }
}

class Student {
    void registerStudent(String name, int age) throws InvalidAgeException {
        // "Age must be above 17" -> valid age is 18 or more
        if (age <= 17) {
            throw new InvalidAgeException("Age must be above 17 for registration");
        }
        System.out.println("Student " + name + " registered successfully.");
    }
}

public class Q2_StudentAge {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter age: ");
        int age = sc.nextInt();

        Student s = new Student();
        try {
            s.registerStudent(name, age);
        } catch (InvalidAgeException e) {
            System.out.println("Exception: " + e.getMessage());
        }
        sc.close();
    }
}
