import java.util.Scanner;

class PrinterJob implements Runnable {
    private int jobNo;
    private String student;

    PrinterJob(int jobNo, String student) {
        this.jobNo = jobNo;
        this.student = student;
    }

    public void run() {
        System.out.println("Printing job " + jobNo + " by " + student);
        try {
            Thread.sleep(1000);   // simulate printing time
        } catch (InterruptedException e) {
            System.out.println("Job " + jobNo + " interrupted");
        }
        System.out.println("Job " + jobNo + " completed");
    }
}

public class Q8_PrinterJob {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Number of print jobs: ");
        int n = sc.nextInt();

        Thread[] threads = new Thread[n];
        for (int i = 0; i < n; i++) {
            String student = "Student " + (char) ('A' + i % 26);
            threads[i] = new Thread(new PrinterJob(i + 1, student));
            threads[i].start();
            Thread.sleep(100);   // small gap so jobs start in order
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("All print jobs finished.");
        sc.close();
    }
}
