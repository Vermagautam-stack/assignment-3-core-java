# CSIT751 (Core Java) – Module III Practical Home Assignment

Exception Handling and Threads in Java – solutions to Q1 to Q10.

| File | Topic |
|------|-------|
| Q1_ATM.java | throw, try-catch-finally (insufficient balance) |
| Q2_StudentAge.java | User-defined exception (InvalidAgeException) |
| Q3_ArrayDivision.java | Multiple catch blocks |
| Q4_StudentMarks.java | Input validation with try-catch-finally |
| Q5_UniversityLogin.java | NullPointerException handling |
| Q6_OnlineShopping.java | User-defined exception (MinimumAmountException) |
| Q7_TicketBooking.java | Thread synchronization |
| Q8_PrinterJob.java | Multiple threads with Runnable |
| Q9_IoTSensor.java | Multithreading (Random / Square / Cube) |
| Q10_BankTransaction.java | Thread priorities |

## How to run
```
javac Q1_ATM.java
java Q1_ATM
```
(Replace Q1_ATM with the file you want to run.)

## Notes
- Q2: valid age is 18 or more ("above 17").
- Q5: typing the word `null` is treated as a null username.
- Q10: amounts of 10000 or more are treated as high value.
