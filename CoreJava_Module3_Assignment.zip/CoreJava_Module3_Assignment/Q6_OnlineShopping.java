import java.util.Scanner;

class MinimumAmountException extends Exception {
    MinimumAmountException(String message) {
        super(message);
    }
}

class OnlineShopping {
    void placeOrder(int amount) throws MinimumAmountException {
        if (amount < 500) {
            throw new MinimumAmountException("Minimum cart value must be \u20B9500");
        }
        System.out.println("Order placed successfully for \u20B9" + amount);
    }
}

public class Q6_OnlineShopping {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter cart amount: ");
        int amount = sc.nextInt();

        OnlineShopping shop = new OnlineShopping();
        try {
            shop.placeOrder(amount);
        } catch (MinimumAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        }
        sc.close();
    }
}
