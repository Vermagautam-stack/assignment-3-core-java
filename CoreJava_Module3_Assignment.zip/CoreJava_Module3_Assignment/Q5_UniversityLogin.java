import java.util.Scanner;

class UniversityLogin {
    void login(String username) {
        // calling a method on null triggers NullPointerException
        System.out.println("Login successful. Welcome, " + username.trim() + "!");
    }
}

public class Q5_UniversityLogin {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String input = sc.nextLine();
        // Typing the word "null" is treated as a null username
        String username = input.equalsIgnoreCase("null") ? null : input;

        UniversityLogin ul = new UniversityLogin();
        try {
            ul.login(username);
        } catch (NullPointerException e) {
            System.out.println("Exception: Username cannot be null");
        }
        sc.close();
    }
}
