import java.util.Scanner;

class TicketBooking {
    private int availableSeats;

    TicketBooking(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    // synchronized: only one thread can book at a time -> no race condition
    synchronized void bookSeat(String user, int seats) {
        if (seats <= availableSeats) {
            availableSeats -= seats;
            System.out.println(user + " booked " + seats + " seat(s) successfully");
        } else {
            System.out.println(user + " booking failed. Not enough seats");
        }
    }
}

class User1 extends Thread {
    private TicketBooking tb;
    private int seats;

    User1(TicketBooking tb, int seats) {
        this.tb = tb;
        this.seats = seats;
    }

    public void run() {
        tb.bookSeat("User1", seats);
    }
}

class User2 extends Thread {
    private TicketBooking tb;
    private int seats;

    User2(TicketBooking tb, int seats) {
        this.tb = tb;
        this.seats = seats;
    }

    public void run() {
        tb.bookSeat("User2", seats);
    }
}

public class Q7_TicketBooking {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Available Seats: ");
        int available = sc.nextInt();
        System.out.print("User1 wants to book: ");
        int s1 = sc.nextInt();
        System.out.print("User2 wants to book: ");
        int s2 = sc.nextInt();

        TicketBooking tb = new TicketBooking(available);
        User1 u1 = new User1(tb, s1);
        User2 u2 = new User2(tb, s2);

        u1.start();
        u1.join();   // join keeps the output order same as the expected output
        u2.start();
        u2.join();
        sc.close();
    }
}
